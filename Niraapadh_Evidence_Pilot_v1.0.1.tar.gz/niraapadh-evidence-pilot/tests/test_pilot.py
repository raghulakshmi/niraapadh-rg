import copy,importlib.util,json,os,subprocess,sys,tempfile,unittest
from datetime import datetime,timezone,timedelta
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app import adapter,store
from app.server import create_app,validate
spec=importlib.util.spec_from_file_location('collector',ROOT/'collector/collector.py');collector=importlib.util.module_from_spec(spec);spec.loader.exec_module(collector)
P={'name':'Test profile','customer':'Test','host':'driveit-server','target_id':'driveit-local','adapter':'restic-driveit-json','timer':'niraapadh-backup.timer','service':'niraapadh-backup.service','script':'/usr/local/sbin/niraapadh-backup','runs_log':'/var/log/niraapadh-backup/runs.jsonl','paths':['/srv/niraapadh-rpo-test'],'exclusions':[],'schedule_minutes':15,'local_repository':'/tmp/repo','bucket':'dtpl-backups','region':'us-east-1','prefix':'driveit-server/restic','tag':'niraapadh-rpo','policy_ref':'TEST-POLICY','policy_status':'draft','rpo_minutes':15,'lookback_hours':24,'completion_grace_seconds':720}

def fixture():
    e={'collection_id':'test-observation','host':'driveit-server','completed_at':'2026-10-04T10:01:00+00:00','approved_target':{'target_id':'driveit-local','expected_host':'driveit-server',**{k:P[k] for k in ('timer','service','script','runs_log')}},'sources':{'clock':{'status':'ok','text':'NTPSynchronized=yes'},'timer_unit':{'status':'ok','text':'OnCalendar=*-*-* *:00,15,30,45:00 UTC'},'timer_state':{'text':'ActiveState=active'},'runs':{'status':'ok','records':[],'lookback_hours':24}},'repositories':{}}
    for d in ('local','s3'):
        e['repositories'][d]={'status':'ok','repository':P['local_repository'] if d=='local' else 's3:https://s3.us-east-1.amazonaws.com/dtpl-backups/driveit-server/restic','observed_at':e['completed_at'],'snapshots':[{'id':'a'*64,'time':'2026-10-04T10:00:00Z','hostname':'driveit-server','paths':P['paths'],'tags':['niraapadh-rpo'],'excludes':[]}]}
    return e
class AssessmentTests(unittest.TestCase):
    def test_freshness_not_claimed_as_verified_rpo(self):
        r=adapter.assess(P,fixture());self.assertEqual(r['overall'],'freshness_observed');self.assertIn('Not established',r['rpo_assurance']);self.assertEqual(r['repositories']['s3']['age_minutes'],1)
    def test_s3_unavailable_never_passes(self):
        e=fixture();e['repositories']['s3']={'status':'error','error':'exit_1'};self.assertEqual(adapter.assess(P,e)['repositories']['s3']['status'],'insufficient_evidence')
    def test_malformed_snapshot_is_unknown(self):
        e=fixture();e['repositories']['local']['snapshots'][0].pop('id');self.assertEqual(adapter.assess(P,e)['repositories']['local']['status'],'insufficient_evidence')
    def test_future_or_unsynchronized_clock(self):
        e=fixture();e['repositories']['local']['snapshots'][0]['time']='2030-01-01T00:00:00Z';self.assertEqual(adapter.assess(P,e)['repositories']['local']['status'],'insufficient_evidence')
        e=fixture();e['sources']['clock']['text']='NTPSynchronized=no';self.assertEqual(adapter.assess(P,e)['repositories']['local']['status'],'insufficient_evidence')
    def test_stale_and_wrong_scope(self):
        e=fixture();e['repositories']['s3']['snapshots'][0]['time']='2026-10-04T09:30:00Z';self.assertEqual(adapter.assess(P,e)['repositories']['s3']['status'],'freshness_exceeded')
        e=fixture();e['repositories']['s3']['snapshots'][0]['excludes']=['secret'];self.assertEqual(adapter.assess(P,e)['repositories']['s3']['status'],'scope_mismatch')
    def test_expected_slots_include_missing(self):
        r=adapter.assess(P,fixture());self.assertEqual([s['status'] for s in r['last_three_expected']],['pending','missing','missing'])
    def test_incomplete_history_is_not_missing(self):
        e=fixture();e['sources']['runs']['truncated']=True;self.assertEqual(adapter.assess(P,e)['last_three_expected'][1]['status'],'insufficient_evidence')
    def test_calendar_reset_and_unsupported(self):
        self.assertEqual(adapter.minutes('OnCalendar=weekly\nOnCalendar=\nOnCalendar=*-*-* *:00,30:00 UTC'),[0,30]);self.assertIsNone(adapter.minutes('OnCalendar=hourly'))
    def test_success_without_catalog_is_conflict(self):
        e=fixture();e['sources']['runs']['records']=[{'host':'driveit-server','run_id':'r1','started_at':'2026-10-04T09:45:00Z','s3':{'status':'success','snapshot_id':'b'*64}}];self.assertEqual(len(adapter.assess(P,e)['repositories']['s3']['conflicts']),1)
class CollectorSafetyTests(unittest.TestCase):
    def test_timeout_and_limit(self):
        self.assertEqual(collector.run([sys.executable,'-c','import time;time.sleep(3)'],timeout=.1)['error'],'timeout')
        self.assertEqual(collector.run([sys.executable,'-c','print("x"*100000)'],limit=100)['error'],'output_limit')
    def test_no_shell_env_execution(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'env';p.write_text('AWS_ACCESS_KEY_ID=$(touch /tmp/niraapadh-bad-test)');p.chmod(0o600)
            with self.assertRaises(ValueError):collector.env_file(p)
    def test_redaction(self):self.assertNotIn('my-secret-value',collector.sanitize('key=my-secret-value',['my-secret-value']))
class APITests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.old=(store.STATE,store.SPOOL);store.STATE=Path(self.tmp.name)/'db';store.SPOOL=Path(self.tmp.name)/'spool';store.SPOOL.mkdir()
        from werkzeug.security import generate_password_hash
        self.app=create_app({'session_secret':'test-only','username':'analyst','password_hash':generate_password_hash('test-password-long'),'target':{'target_id':'driveit-local'},'allowed_origins':['http://localhost']});self.client=self.app.test_client();self.headers={'Origin':'http://localhost'}
    def tearDown(self):store.STATE,store.SPOOL=self.old;self.tmp.cleanup()
    def login(self):
        r=self.client.post('/api/login',json={'username':'analyst','password':'test-password-long'},headers=self.headers);self.assertEqual(r.status_code,200);self.headers['X-CSRF-Token']=r.json['csrf']
    def test_auth_csrf_and_host(self):
        self.assertEqual(self.client.get('/api/bootstrap').status_code,401)
        self.login();self.assertEqual(self.client.post('/api/profiles',json=P,headers={'Origin':'http://localhost'}).status_code,403)
        self.assertEqual(self.client.get('/api/bootstrap',headers={'Host':'evil.example'}).status_code,400)
    def test_profile_revision_persistence_ingestion_and_evidence(self):
        self.login();r=self.client.post('/api/profiles',json=P,headers=self.headers);self.assertEqual(r.status_code,200);ident=r.json['id']
        e=fixture();(store.SPOOL/'test-observation.json').write_text(json.dumps(e));store.ingest()
        result=self.client.get('/api/profiles/'+ident+'/results');self.assertEqual(result.status_code,200);self.assertEqual(len(result.json['observations']),1)
        update=dict(P,id=ident,rpo_minutes=30);self.assertEqual(self.client.post('/api/profiles',json=update,headers=self.headers).status_code,200)
        store.ingest();self.assertEqual(store.list_profiles()[0]['revision'],2)
        self.assertEqual(self.client.get('/api/evidence/test-observation').status_code,200)
        with store.db() as c:self.assertEqual(c.execute('SELECT count(*) FROM profile_versions').fetchone()[0],2)
    def test_clock_fix_preserves_previous_assessment_and_evidence(self):
        self.login();ident=self.client.post('/api/profiles',json=P,headers=self.headers).json['id']
        old=fixture();old['sources']['clock']['text']='';(store.SPOOL/'test-observation.json').write_text(json.dumps(old));store.ingest()
        with store.db() as c:
            before=c.execute('SELECT body FROM assessments WHERE profile_id=?',(ident,)).fetchone()[0]
            evidence_before=tuple(c.execute('SELECT body,sha256 FROM collections WHERE id=?',('test-observation',)).fetchone())
        new=fixture();new['collection_id']='clock-fixed';new['completed_at']='2026-10-04T10:02:00+00:00';(store.SPOOL/'clock-fixed.json').write_text(json.dumps(new));store.ingest()
        response=self.client.get('/api/profiles/'+ident+'/results').json
        self.assertEqual(response['total'],2);self.assertEqual(response['latest']['overall'],'freshness_observed')
        self.assertEqual(response['observations'][1]['overall'],'insufficient_evidence')
        saved=self.client.get('/api/profiles/'+ident+'/assessments/1/test-observation')
        self.assertEqual(saved.status_code,200);self.assertFalse(saved.json['assessment']['clock_synchronized']);self.assertEqual(saved.json['profile'],P)
        with store.db() as c:
            self.assertEqual(before,c.execute('SELECT body FROM assessments WHERE profile_id=? AND collection_id=?',(ident,'test-observation')).fetchone()[0])
            self.assertEqual(evidence_before,tuple(c.execute('SELECT body,sha256 FROM collections WHERE id=?',('test-observation',)).fetchone()))
    def test_history_pagination_and_old_profile_revision(self):
        self.login();ident=self.client.post('/api/profiles',json=P,headers=self.headers).json['id']
        e=fixture();(store.SPOOL/'test-observation.json').write_text(json.dumps(e));store.ingest()
        self.client.post('/api/profiles',json=dict(P,id=ident,rpo_minutes=30),headers=self.headers);store.ingest()
        page=self.client.get('/api/profiles/'+ident+'/results?limit=1&offset=1').json
        self.assertEqual(page['total'],2);self.assertEqual(page['observations'][0]['profile_revision'],1);self.assertEqual(page['latest']['profile_revision'],2)
        self.assertEqual(self.client.get('/api/profiles/'+ident+'/results?limit=999').status_code,400)
        self.assertEqual(self.client.get('/api/profiles/'+ident+'/assessments/9/test-observation').status_code,404)
    def test_unsupported_adapter_and_credential_fields(self):
        self.login();p=dict(P,adapter='veeam');self.assertEqual(self.client.post('/api/profiles',json=p,headers=self.headers).status_code,400)
        p=dict(P,password='must-not-persist');self.client.post('/api/profiles',json=p,headers=self.headers);self.assertNotIn('password',store.list_profiles()[0])
class LiveResticTests(unittest.TestCase):
    @unittest.skipUnless(os.environ.get('RESTIC_TEST_BIN'),'Set RESTIC_TEST_BIN for real repository integration')
    def test_three_real_backups_copy_restore_and_collector(self):
        binary=os.environ['RESTIC_TEST_BIN']
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);source=root/'protected';source.mkdir();repo=root/'repo';copyrepo=root/'copy';password=root/'password';password.write_text('temporary-test-password-never-used-in-production');password.chmod(0o600)
            env={**os.environ,'RESTIC_PASSWORD_FILE':str(password)}
            def cli(*args):return subprocess.run([binary,*map(str,args)],env=env,capture_output=True,check=True).stdout.decode()
            cli('-r',repo,'init');cli('-r',copyrepo,'init')
            for i in range(3):
                (source/'record.txt').write_text('record '+str(i));cli('-r',repo,'backup',source,'--host','driveit-server','--tag','niraapadh-rpo','--tag','run-'+str(i),'--json')
            cli('-r',copyrepo,'copy','--from-repo',repo,'--from-password-file',password)
            snapshots=json.loads(cli('--no-lock','--no-cache','-r',repo,'snapshots','--json'))
            copied=json.loads(cli('--no-lock','--no-cache','-r',copyrepo,'snapshots','--json'));self.assertEqual(len(snapshots),3);self.assertEqual(len(copied),3)
            cli('-r',copyrepo,'restore','latest','--target',root/'restore');self.assertEqual((root/'restore'/str(source).lstrip('/')/'record.txt').read_text(),'record 2')
            envpath=root/'backup.env';envpath.write_text(f"RESTIC_PASSWORD_FILE='{password}'\nLOCAL_REPOSITORY='{repo}'\nS3_REPOSITORY='invalid'\n");envpath.chmod(0o600)
            script=root/'backup';script.write_text('restic backup /test');script.chmod(0o700)
            cfg=dict(target_id='driveit-local',expected_host='driveit-server',timer='niraapadh-backup.timer',service='niraapadh-backup.service',script=str(script),runs_log=str(root/'runs.jsonl'),env_file=str(envpath),restic_binary=binary,tag='niraapadh-rpo',lookback_hours=24)
            e=collector.collect(cfg);self.assertEqual(e['repositories']['local']['status'],'ok');self.assertEqual(len(e['repositories']['local']['snapshots']),3);self.assertEqual(e['repositories']['s3']['status'],'error');self.assertNotIn(password.read_text(),json.dumps(e))
            report={'restic_version':cli('version').strip(),'actual_backups':len(snapshots),'actual_copied_snapshots':len(copied),'restore_content_verified':True,'collector_local_query':'passed','s3_live_access':'not tested; customer credentials not available'}
            print('\nLIVE INTEGRATION: '+json.dumps(report))
if __name__=='__main__':unittest.main(verbosity=2)
