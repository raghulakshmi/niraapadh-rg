#!/usr/bin/env bash
set -euo pipefail
[[ $(id -u) -eq 0 ]] || { echo 'Run: sudo bash upgrade.sh'; exit 1; }
SOURCE_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
APP_DIR=/opt/niraapadh-evidence
[[ -f "$APP_DIR/VERSION" && -f /var/lib/niraapadh-evidence/evidence.sqlite3 ]] || { echo 'Existing pilot/database not found. Use install.sh only for a new installation.'; exit 1; }
CURRENT_VERSION=$(cat "$APP_DIR/VERSION")
if [[ "$CURRENT_VERSION" = 1.0.1 ]]; then echo 'Version 1.0.1 is already installed.'; exit 0; fi
[[ "$CURRENT_VERSION" = 1.0.0 ]] || { echo "Unsupported installed version: $CURRENT_VERSION"; exit 1; }
cd "$SOURCE_DIR"
sha256sum -c SHA256SUMS >/dev/null
python3 - "$SOURCE_DIR" "$APP_DIR" <<'PY'
import hashlib,json,pathlib,sys
source,app=map(pathlib.Path,sys.argv[1:])
for name,hashes in json.loads((source/'upgrade-supported-hashes.json').read_text()).items():
 p=app/name
 if p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest() not in hashes:
  raise SystemExit('Local customization detected in '+name+'. No changes made. Merge this file manually before upgrading.')
print('Installed source matches v1.0.0 (including the optional clock hotfix).')
PY
# Preserve prior running states. Stop only application services, never backup jobs.
RESTART_UNITS=()
for unit in niraapadh-evidence-web.service niraapadh-evidence-collector.timer niraapadh-evidence-ingest.timer; do
 if systemctl is-active --quiet "$unit"; then RESTART_UNITS+=("$unit"); fi
done
install -d -o root -g root -m 700 /var/backups/niraapadh-evidence-upgrades
BACKUP_DIR=$(mktemp -d /var/backups/niraapadh-evidence-upgrades/v1.0.0-XXXXXXXX)
chmod 700 "$BACKUP_DIR"
CODE_CHANGED=0
recover() {
 local result=$?
 trap - EXIT
 if [[ $result -ne 0 && $CODE_CHANGED -eq 1 ]]; then
  cp -a "$BACKUP_DIR/app/." "$APP_DIR/app/"
  cp -a "$BACKUP_DIR/collector/." "$APP_DIR/collector/"
  cp -a "$BACKUP_DIR/VERSION" "$APP_DIR/VERSION"
  echo 'Code restored from backup; database was not replaced.'
 fi
 if [[ ${#RESTART_UNITS[@]} -gt 0 ]]; then systemctl start "${RESTART_UNITS[@]}" || true; fi
 if [[ $result -ne 0 ]]; then echo "Upgrade stopped. Backup directory: $BACKUP_DIR"; fi
 exit "$result"
}
trap recover EXIT
systemctl stop niraapadh-evidence-collector.timer niraapadh-evidence-ingest.timer niraapadh-evidence-web.service
systemctl stop niraapadh-evidence-collector.service niraapadh-evidence-ingest.service
cd "$APP_DIR"
# Import any pending old records using the old code before creating the backup.
sudo -u niraapadh-evidence "$APP_DIR/venv/bin/python" -m app.manage ingest
cp -a "$APP_DIR/app" "$APP_DIR/collector" "$APP_DIR/VERSION" "$BACKUP_DIR/"
python3 - "$BACKUP_DIR" <<'PY'
import sqlite3,sys,pathlib
source=sqlite3.connect('/var/lib/niraapadh-evidence/evidence.sqlite3')
with sqlite3.connect(pathlib.Path(sys.argv[1])/'evidence.sqlite3') as target:source.backup(target)
source.close()
PY
CODE_CHANGED=1
for file in app/server.py app/static/app.js app/static/style.css app/static/index.html collector/collector.py; do
 install -o root -g root -m 644 "$SOURCE_DIR/$file" "$APP_DIR/$file"
done
"$APP_DIR/venv/bin/python" -m compileall -q "$APP_DIR/app" "$APP_DIR/collector"
printf '1.0.1\n' > "$APP_DIR/VERSION"
sudo -u niraapadh-evidence "$APP_DIR/venv/bin/python" -m app.manage ingest
python3 - "$BACKUP_DIR" <<'PY'
import sqlite3,pathlib,sys
old=sqlite3.connect(pathlib.Path(sys.argv[1])/'evidence.sqlite3')
current=sqlite3.connect('/var/lib/niraapadh-evidence/evidence.sqlite3')
# Assert that every prior evidence/assessment/profile row is still identical.
for table in ('collections','assessments','profiles','profile_versions'):
 columns=[r[1] for r in old.execute('PRAGMA table_info('+table+')')]
 predicate=' AND '.join('"'+col+'" IS ?' for col in columns)
 for row in old.execute('SELECT * FROM '+table):
  if current.execute('SELECT 1 FROM '+table+' WHERE '+predicate+' LIMIT 1',row).fetchone() is None:
   raise SystemExit('Preservation verification failed for '+table)
print('Verified: all prior evidence, saved assessments and profiles are unchanged.')
PY
if [[ ${#RESTART_UNITS[@]} -gt 0 ]]; then systemctl start "${RESTART_UNITS[@]}"; fi
if [[ " ${RESTART_UNITS[*]} " == *" niraapadh-evidence-web.service "* ]]; then
 sleep 2
 systemctl is-active --quiet niraapadh-evidence-web.service || { echo 'Web service did not remain running'; exit 1; }
fi
CODE_CHANGED=0
printf '\nUpgrade complete. Backup: %s\n' "$BACKUP_DIR"
printf 'Refresh your browser. Open Evidence > Evidence collection history > View run.\n'
printf 'Click Collect now to obtain a new observation after the included clock fix.\n'
