# Niraapadh Evidence Pilot — working on-premises application

Version 1.0.1 • Prepared for DriveIT • 5 October 2026

This package contains executable software, not the previously hosted simulation.
It runs on `driveit-server`, collects actual backup evidence and stores profiles and assessments in SQLite.
It has not been installed on your server by this delivery; the commands below perform installation.

## Upgrade an existing v1.0.0 installation

Use `upgrade.sh`, not `install.sh`:

```bash
tar -xzf Niraapadh_Evidence_Pilot_v1.0.1.tar.gz
cd niraapadh-evidence-pilot
sudo bash upgrade.sh
```

The upgrade accepts the original collector or the collector with the previously supplied one-line clock fix. It checks installed file hashes and stops before changes if it detects other customizations. It briefly stops only the evidence application services, imports pending old observations, backs up application code and the SQLite database under `/var/backups/niraapadh-evidence-upgrades/`, and installs the patch. Before completion, it verifies that every pre-existing collection, assessment, profile and profile revision remains unchanged. Credentials, configuration, source evidence files and backup jobs are not replaced. Application services that were active before the upgrade are restarted.

This release includes the clock-property fix. It does not set the clock or enable NTP: synchronization must actually be reported by the host. Historical observations with empty clock evidence retain their original “insufficient evidence” result.

Refresh the browser, open **Evidence**, and use **Evidence collection history**:

- **View run** selects an earlier collection and shows its original findings.
- **Selected run compared with latest** shows clock state, local/S3 freshness and policy target for both observations.
- **Download this evidence** downloads that collection's original stored evidence content.
- **Download this assessment** downloads the saved assessment and associated profile revision.
- **Newer / Older** page through all saved assessments, including earlier profile revisions.
- **View latest** resumes following new evidence. An explicitly selected historical run stays selected while new collections arrive.

The upgrade does not rewrite old verdicts with new clock information. Click **Collect now** to obtain a new observation. If the host reports `NTPSynchronized=yes` and snapshot freshness is within the configured target, the new record can show “freshness within target.” That does not change the earlier run or imply a tested restore.

Assessments are indexed by profile, profile revision and collection ID. The existing pilot can assess older collected evidence against a new profile revision; these are shown as separate revision-labelled records, never as replacements of earlier assessments. “Collected UTC” is the evidence timestamp, not the timestamp when a later revision was applied.

There is no automatic deletion in this pilot. This is application-level preservation, not immutable/WORM storage; privileged database administrators can still alter records.

## What is implemented

- Authenticated web application, served by Gunicorn as an unprivileged service.
- Five-step named-profile wizard with mandatory inputs and persistent revisions.
- An adapter dropdown and adapter catalog. Restic + the DriveIT `runs.jsonl` wrapper is implemented; other entries are visibly unavailable.
- A root-owned, fixed-target Linux collector. The web profile cannot supply commands or change privileged collection paths.
- Actual systemd configuration/state, clock state, selected journal metadata, source-script fingerprint and structured job history.
- Actual local and S3 Restic snapshot queries (`--no-lock --no-cache snapshots --json`). No backup, copy, restore, prune or delete action is performed by the collector.
- Manual collection and systemd-driven collection every five minutes, independent of an open browser. Ingestion/assessment runs every minute.
- Recent actual executions and last three expected schedule slots (supported calendar syntax described below).
- Destination-specific snapshot freshness, protected-path/exclusion metadata comparison, schedule mismatch checks and evidence gaps.
- Saved evidence, SHA-256 fingerprints, assessment history, profile revision history and basic audit entries.
- JSON evidence download. Secret configuration is not sent to the browser.

## Architecture

Browser → authenticated Flask/Gunicorn API → SQLite profiles/assessments.

A separate root-owned systemd collector reads the approved server configuration and uses credentials already on the host to query Restic. It atomically writes selected, redacted evidence to a root-owned spool. The unprivileged ingestion service imports these records and applies the Restic adapter to named profiles.

“Collect now” can start only the exact collector systemd service through a narrowly scoped sudoers entry. It cannot pass a command, repository or file path to the privileged collector.

## Prerequisites

- The existing Ubuntu `driveit-server` installation with systemd and Python 3.
- Restic already installed (the original lab used 0.18.1).
- Your existing backup configuration and password file:
  - `/etc/niraapadh-backup/backup.env`
  - `/etc/niraapadh-backup/repository-password`
- Both secret files must be root-owned, mode `0600`, and not symbolic links.
- Existing timer/service/script/history from the backup runbook:
  - `niraapadh-backup.timer`
  - `niraapadh-backup.service`
  - `/usr/local/sbin/niraapadh-backup`
  - `/var/log/niraapadh-backup/runs.jsonl`
- Internet access for Python package installation and the S3 query. The installer installs Python venv/sudo packages only if needed. It does not install or reinitialize Restic or modify your backup jobs.
- Port 8787 unused. Initial access uses an SSH tunnel, so no inbound firewall change is necessary.

## 1. Install on driveit-server

Copy `Niraapadh_Evidence_Pilot_v1.0.1.tar.gz` to the server, then:

```bash
tar -xzf Niraapadh_Evidence_Pilot_v1.0.1.tar.gz
cd niraapadh-evidence-pilot
sudo bash install.sh
```

The installer prompts for an analyst password of at least 14 characters. Username: `analyst`.
It creates dedicated application services and starts real evidence collection. It does not create a sample profile or seed sample evidence.

If installation fails before completion, correct the reported problem and rerun it. Once `/opt/niraapadh-evidence/VERSION` exists, the first-install script refuses to overwrite a completed installation. See maintenance below.

## 2. Open the app from your computer

On your own computer (not in the remote server shell), keep this SSH session open:

```bash
ssh -N -L 8787:127.0.0.1:8787 driveit@driveit-server
```

Use the server IP in place of `driveit-server` if name resolution is unavailable.
Open **http://localhost:8787** and sign in. The HTTP hop is loopback; traffic to the server is carried inside SSH. Do not expose the HTTP listener to your LAN.

## 3. Create the named profile

Click **Create profile**. The form is prefilled for your existing lab, but it is not saved until you review it.

| Field | Initial value |
|---|---|
| Name | DriveIT-Ubuntu-Restic-Backup |
| Customer | DriveIT |
| Host | driveit-server |
| Adapter | Restic + DriveIT job JSON |
| Approved target | driveit-local |
| Timer / service | niraapadh-backup.timer / niraapadh-backup.service |
| Script | /usr/local/sbin/niraapadh-backup |
| History | /var/log/niraapadh-backup/runs.jsonl |
| Protected paths | /srv/niraapadh-rpo-test |
| Exclusions | Empty (none) |
| Job tag | niraapadh-rpo |
| Declared backup interval | 15 minutes |
| History window | 24 hours |
| Completion grace | 720 seconds |
| Local repository | /var/backups/niraapadh/restic |
| S3 bucket / region | dtpl-backups / us-east-1 |
| S3 prefix | driveit-server/restic |
| Policy reference | DTPL-POL-BKP-001 |
| Policy status | Draft until actually approved |
| RPO target | 15 minutes |

The completion grace affects expected-job status only; it does not relax the RPO target. Enter additional protected paths or exclusions separated by semicolons.

The policy reference, approval status and RPO are entered by the analyst. Automatic document parsing, approval workflow and policy authenticity verification are not implemented.

Save, open **Evidence**, then click **Collect now**. A local/S3 query may take several minutes. The page refreshes every five seconds. An unavailable repository returns an error or insufficient-evidence finding, never a synthetic pass.

## 4. Verify real collection

```bash
sudo bash verify.sh
```

This triggers actual read-only collection, imports evidence, and prints repository statuses and snapshot counts without credentials.

For service diagnostics:

```bash
sudo journalctl -u niraapadh-evidence-collector.service -n 50 --no-pager
sudo journalctl -u niraapadh-evidence-ingest.service -n 50 --no-pager
sudo journalctl -u niraapadh-evidence-web.service -n 50 --no-pager
```

A repository error code is intentionally shown without raw Restic stderr: backend errors can contain credential-bearing URLs. Investigate using an authorized root shell; never paste credentials or the environment file into chat.

## 5. Direct HTTPS access for the engineering team

Use an internal DNS name resolving to this server and a certificate trusted by the team's devices. The certificate must cover that DNS name. Then run:

```bash
sudo bash enable-https.sh evidence.driveittech.in /path/fullchain.pem /path/privkey.pem
```

The script verifies certificate/key matching and hostname coverage, copies them with restricted permissions, enables secure cookies, changes allowed origins, and binds TLS on port 8787.

Team URL: **https://evidence.driveittech.in:8787**.

Restrict TCP 8787 to the intended internal subnet using your existing firewall. DNS setup and certificate issuance are outside this installer. Existing Apache/iTop services and ports 80/443 are untouched. The pilot uses a shared analyst account; individual users, SSO and role-based permissions are future work.

## Configuration and access

Root-only collector configuration: `/etc/niraapadh-evidence/collector.json`.
Web configuration: `/etc/niraapadh-evidence/web.json` (root-owned, readable by the application group).

For this first pilot, only one administrator-approved local target is supported. Web profiles describe its expected configuration and policy; they do not authorize new collection targets. To change the actual permitted target, an administrator must update collector configuration, update the public target description in web configuration, and restart the web service. No SSH password field is necessary because collection runs locally.

The collector parses `backup.env` as literal `KEY=value` assignments. It never sources it as shell code. Variable expansion, command substitution and dynamic shell expressions are rejected. Quoted literal values are supported.

The S3 repository must be a literal value such as:

```text
s3:https://s3.us-east-1.amazonaws.com/dtpl-backups/driveit-server/restic
```

Do not use Markdown link notation such as `s3:[https://...](https://...)` in the actual environment file.

Only the needed AWS environment variables and the Restic password-file reference are passed to the Restic subprocess. The pilot initially reuses the existing backup credentials. Its commands are read-only, but the credential itself may have broader rights. For stronger separation, prepare a separate root-owned collection environment file with AWS `ListBucket`, `GetBucketLocation` and `GetObject` access restricted to the repository, then change `env_file` in collector configuration. Repository initialization/lock/write/delete permissions are not requested by these snapshot queries. The existing repository password is still needed to decrypt snapshot metadata.

## Meaning of the results

- **Freshness within target:** the newest matching snapshot's start timestamp was within the entered RPO interval at observation time, and clock synchronization was reported. This is a timestamp proxy, not proof of application-consistent RPO or recoverability.
- **Freshness exceeded:** the matching snapshot's age exceeded the target at observation time.
- **Insufficient evidence:** access, clock, timestamps or repository data could not establish freshness.
- **Scope mismatch:** no snapshot matches the declared exact path set and exclusions. Parent-directory equivalence and arbitrary exclusion semantics are intentionally not inferred.
- **Success/catalog conflict:** a success log refers to a snapshot not in the queried retained catalog. This can reflect retention, deletion or inconsistent evidence; it needs investigation.
- **Stale collection:** the latest observation is more than ten minutes old. Prior findings remain historical and do not describe current protection.
- **Last three expected executions:** supported for explicit minute-list calendars such as `*-*-* *:00,15,30,45:00 UTC`. Other formats are marked unsupported. A run starting within 60 seconds is associated with a slot; this does not prove it was timer-triggered. Catch-up and manual runs remain visible in actual run history. Missing/failed/interrupted executions are not filtered out.

S3 copy time is not a new data-capture timestamp. Job completion time, if corroborated by a matching snapshot, is retained separately from snapshot time. Historical observations are stored, but this version does not certify continuous 24-hour RPO or reconstruct all historical availability intervals. No automatic restore test or integrity scan runs on customer data.

## Persistence and maintenance

| Location | Contents |
|---|---|
| /opt/niraapadh-evidence | Root-owned source and Python environment |
| /var/lib/niraapadh-evidence/evidence.sqlite3 | Profiles, revisions, observations, assessments and audit records |
| /var/lib/niraapadh-collector | Root-owned collected JSON evidence, group-readable by app |
| /etc/niraapadh-evidence | Approved target, web settings and optional TLS files |

Evidence is currently retained until an administrator removes it. Monitor disk space; this pilot does not implement retention rotation, immutable storage or cryptographic signing. A SHA-256 hash detects changes relative to the saved hash but does not establish trusted provenance if both the record and hash are altered. Back up the application database/configuration according to your policy; protect credentials and TLS keys separately.

To reset the password:

```bash
cd /opt/niraapadh-evidence
sudo /opt/niraapadh-evidence/venv/bin/python -m app.manage set-password
sudo systemctl restart niraapadh-evidence-web.service
```

For an intentional code upgrade: stop the three application services and both application timers, take a consistent SQLite backup, preserve `/etc/niraapadh-evidence`, review and install the updated source/dependencies, then restart. Do not rerun the first-install script over a completed installation. The existing backup timer is separate and must not be stopped as part of an application upgrade.

To stop this pilot without touching backup jobs:

```bash
sudo systemctl disable --now niraapadh-evidence-collector.timer niraapadh-evidence-ingest.timer niraapadh-evidence-web.service
sudo systemctl stop niraapadh-evidence-collector.service niraapadh-evidence-ingest.service
```

This leaves evidence and configuration intact.

## Engineering extension points

- `collector/collector.py`: bounded command/file collection, secret handling and approved target.
- `app/adapter.py`: Restic interpretation and freshness/job checks.
- `app/store.py`: persistence and ingestion.
- `app/server.py`: authenticated API, validation and adapter catalog.
- `app/static/`: actual profile wizard and evidence UI.
- `deploy/`: service separation and schedules.

A new adapter needs a validated input schema, restricted collection actions, normalization/parser logic, tests and explicit support boundaries. Registering a dropdown label is insufficient. This first implementation is intentionally limited to the existing DriveIT Restic wrapper; it is not a universal arbitrary-script parser or multi-tenant collector platform.

## Validation performed before delivery

See `TEST_RESULTS.txt` for this patch and `BASELINE_TEST_RESULTS_v1.0.0.txt` for the original live integration. Baseline tests covered actual Restic 0.18.1 repositories: three backups, copy to another local repository, verified restore content, real collector snapshot queries, and unavailable repository handling. Additional tests cover authentication, host/origin/CSRF protections, persistent revisions, ingestion, unsupported adapters, freshness, scope, missing slots, clock uncertainty, credential redaction and command limits/timeouts.

The S3 transport with your AWS credentials, Ubuntu 26.04 systemd deployment and graphical browser interaction require on-server acceptance. They have not been claimed as tested here. No sample evidence is seeded into the application.

Run tests in an isolated environment (integration test uses temporary directories only):

```bash
python3 -m venv .test-venv
.test-venv/bin/pip install -r requirements.txt
RESTIC_TEST_BIN="$(command -v restic)" .test-venv/bin/python -m unittest discover -s tests -v
```

The privileged ownership tests and collector integration expect root-owned test files; run those tests in an isolated root/container test environment, not by relaxing production permissions.

References: [Restic JSON schema](https://restic.readthedocs.io/en/v0.18.0/075_scripting.html), [Flask/Gunicorn deployment](https://flask.palletsprojects.com/en/stable/deploying/gunicorn/).
