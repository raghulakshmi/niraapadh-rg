#!/usr/bin/env bash
set -euo pipefail
[[ $(id -u) -eq 0 && $# -eq 3 ]] || { echo 'Usage: sudo bash enable-https.sh evidence.internal.example /path/fullchain.pem /path/privkey.pem'; exit 1; }
APP_HOST=$1
[[ "$APP_HOST" =~ ^[a-zA-Z0-9][a-zA-Z0-9.-]+$ ]] || { echo 'Use a DNS hostname, without scheme or port'; exit 1; }
[[ -f "$2" && -f "$3" ]] || { echo 'Certificate and key files are required'; exit 1; }
# Verify key matches certificate before changing the running service.
CERT_PUB=$(openssl x509 -in "$2" -pubkey -noout | openssl pkey -pubin -outform DER | sha256sum)
KEY_PUB=$(openssl pkey -in "$3" -pubout -outform DER | sha256sum)
[[ "$CERT_PUB" = "$KEY_PUB" ]] || { echo 'Certificate/key mismatch'; exit 1; }
openssl x509 -in "$2" -noout -checkhost "$APP_HOST"
install -d -o root -g niraapadh-evidence -m 750 /etc/niraapadh-evidence/tls
install -o root -g niraapadh-evidence -m 640 "$2" /etc/niraapadh-evidence/tls/fullchain.pem
install -o root -g niraapadh-evidence -m 640 "$3" /etc/niraapadh-evidence/tls/privkey.pem
python3 - "$APP_HOST" <<'PY'
import json,pathlib,sys,secrets
p=pathlib.Path('/etc/niraapadh-evidence/web.json');c=json.loads(p.read_text());c['https']=True;c['allowed_origins']=['https://'+sys.argv[1]+':8787'];c['session_secret']=secrets.token_hex(32);p.write_text(json.dumps(c,indent=2)+'\n')
PY
install -d -m 755 /etc/systemd/system/niraapadh-evidence-web.service.d
cat > /etc/systemd/system/niraapadh-evidence-web.service.d/https.conf <<'EOF'
[Service]
ExecStart=
ExecStart=/opt/niraapadh-evidence/venv/bin/gunicorn --workers 1 --threads 4 --bind 0.0.0.0:8787 --certfile /etc/niraapadh-evidence/tls/fullchain.pem --keyfile /etc/niraapadh-evidence/tls/privkey.pem --timeout 120 --access-logfile - app.server:create_app()
EOF
systemctl daemon-reload
systemctl restart niraapadh-evidence-web.service
printf 'Team URL: https://%s:8787\nRestrict TCP 8787 to your approved internal subnet using your existing firewall.\n' "$APP_HOST"
