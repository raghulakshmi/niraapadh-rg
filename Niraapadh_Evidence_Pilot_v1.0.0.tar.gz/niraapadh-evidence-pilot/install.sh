#!/usr/bin/env bash
set -euo pipefail
if [[ $(id -u) -ne 0 ]]; then echo 'Run: sudo bash install.sh'; exit 1; fi
SOURCE_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
[[ -d /run/systemd/system ]] || { echo 'A systemd Ubuntu host is required'; exit 1; }
[[ -f /etc/niraapadh-backup/backup.env ]] || { echo 'Missing existing /etc/niraapadh-backup/backup.env'; exit 1; }
RESTIC_BIN=$(command -v restic) || { echo 'Install Restic first'; exit 1; }
[[ "$RESTIC_BIN" = /* ]] || exit 1
if [[ -L "$RESTIC_BIN" ]]; then RESTIC_BIN=$(readlink -f "$RESTIC_BIN"); fi
if ! command -v python3 >/dev/null || ! command -v sudo >/dev/null || ! python3 -m venv --help >/dev/null 2>&1; then
  apt-get update
  apt-get install -y python3 python3-venv sudo
fi
# Ubuntu can have venv present but its ensurepip package missing.
if ! python3 -m venv /tmp/niraapadh-venv-check-$$; then
  apt-get update
  apt-get install -y python3-venv
fi
rm -rf "/tmp/niraapadh-venv-check-$$"
getent group niraapadh-evidence >/dev/null || groupadd --system niraapadh-evidence
id niraapadh-evidence >/dev/null 2>&1 || useradd --system --gid niraapadh-evidence --home-dir /var/lib/niraapadh-evidence --shell /usr/sbin/nologin niraapadh-evidence
install -d -o root -g root -m 755 /opt/niraapadh-evidence
if [[ -f /opt/niraapadh-evidence/VERSION ]]; then
  echo 'Existing installation detected. This installer is first-install only; see the upgrade instructions.'
  exit 1
fi
install -d -o root -g niraapadh-evidence -m 750 /etc/niraapadh-evidence /var/lib/niraapadh-collector
install -d -o niraapadh-evidence -g niraapadh-evidence -m 700 /var/lib/niraapadh-evidence
cp -R "$SOURCE_DIR/app" "$SOURCE_DIR/collector" /opt/niraapadh-evidence/
cp "$SOURCE_DIR/requirements.txt" /opt/niraapadh-evidence/
chown -R root:root /opt/niraapadh-evidence
chmod -R go-w /opt/niraapadh-evidence
python3 -m venv /opt/niraapadh-evidence/venv
/opt/niraapadh-evidence/venv/bin/pip install -r /opt/niraapadh-evidence/requirements.txt
python3 - "$RESTIC_BIN" <<'PY'
import json,pathlib,sys,os,grp,secrets,socket
root=pathlib.Path('/etc/niraapadh-evidence')
target={'target_id':'driveit-local','expected_host':'driveit-server','timer':'niraapadh-backup.timer','service':'niraapadh-backup.service','script':'/usr/local/sbin/niraapadh-backup','runs_log':'/var/log/niraapadh-backup/runs.jsonl'}
cfg=dict(target,env_file='/etc/niraapadh-backup/backup.env',restic_binary=sys.argv[1],tag='niraapadh-rpo',lookback_hours=24)
p=root/'collector.json'
if not p.exists():p.write_text(json.dumps(cfg,indent=2)+'\n');p.chmod(0o600)
p=root/'web.json'
if not p.exists():
 p.write_text(json.dumps({'username':'analyst','password_hash':'!disabled','session_secret':secrets.token_hex(32),'https':False,'allowed_origins':['http://localhost:8787','http://127.0.0.1:8787'],'target':target},indent=2)+'\n')
 os.chown(p,0,grp.getgrnam('niraapadh-evidence').gr_gid);p.chmod(0o640)
if socket.gethostname()!='driveit-server':print('NOTICE: actual hostname differs from driveit-server; review collector.json before collection.')
PY
cd /opt/niraapadh-evidence
/opt/niraapadh-evidence/venv/bin/python -m app.manage set-password
install -m 644 "$SOURCE_DIR"/deploy/niraapadh-evidence-*.service "$SOURCE_DIR"/deploy/niraapadh-evidence-*.timer /etc/systemd/system/
SUDO_TEMP=$(mktemp)
trap 'rm -f "$SUDO_TEMP"' EXIT
cat > "$SUDO_TEMP" <<'EOF'
niraapadh-evidence ALL=(root) NOPASSWD: /usr/bin/systemctl start niraapadh-evidence-collector.service
EOF
visudo -cf "$SUDO_TEMP"
install -o root -g root -m 440 "$SUDO_TEMP" /etc/sudoers.d/niraapadh-evidence
systemctl daemon-reload
sudo -u niraapadh-evidence /opt/niraapadh-evidence/venv/bin/python -m app.manage ingest
systemctl enable --now niraapadh-evidence-web.service niraapadh-evidence-collector.timer niraapadh-evidence-ingest.timer
printf '1.0.0\n' > /opt/niraapadh-evidence/VERSION
systemctl start --no-block niraapadh-evidence-collector.service
printf '\nInstalled. Username: analyst. App: http://127.0.0.1:8787 (use SSH tunnel from your computer).\n'
printf 'Collector journal: sudo journalctl -u niraapadh-evidence-collector.service -n 30 --no-pager\n'
printf 'For direct team access over HTTPS, see enable-https.sh and README.md.\n'
