#!/usr/bin/env bash
set -euo pipefail
[[ $(id -u) -eq 0 ]] || { echo 'Run: sudo bash verify.sh'; exit 1; }
systemctl is-active niraapadh-evidence-web.service
systemctl is-active niraapadh-evidence-collector.timer
systemctl is-active niraapadh-evidence-ingest.timer
systemctl list-timers --all niraapadh-evidence-collector.timer niraapadh-evidence-ingest.timer
systemctl start niraapadh-evidence-collector.service
cd /opt/niraapadh-evidence
sudo -u niraapadh-evidence /opt/niraapadh-evidence/venv/bin/python -m app.manage ingest
python3 - <<'PY'
import json,pathlib
files=sorted(pathlib.Path('/var/lib/niraapadh-collector').glob('*.json'))
if not files:raise SystemExit('FAIL: no collected evidence file')
e=json.loads(files[-1].read_text())
print('Collection:',e['collection_id'])
print('Host:',e['host'])
failed=False
for name,r in e['repositories'].items():
 print(name, 'status:',r['status'], 'snapshot count:',len(r.get('snapshots',[])), 'error:',r.get('error'))
 if r['status']!='ok':failed=True
print('Run-history status:',e['sources']['runs']['status'])
print('Run-history records:',len(e['sources']['runs']['records']))
if failed:raise SystemExit('Repository evidence incomplete. Review configuration/access before assessment.')
print('Collection works. This does not establish RPO compliance or restore assurance.')
PY
