#!/usr/bin/python3
"""Privileged, fixed-target collector. No UI inputs or shell execution."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import shlex
import signal
import socket
import stat
import subprocess
import tempfile
import time

UTC=dt.timezone.utc
VERSION='1.0.0'
CONFIG=Path('/etc/niraapadh-evidence/collector.json')
LIMIT=8*1024*1024

def now(): return dt.datetime.now(UTC).isoformat()
def stamp(text):
    try:
        value=dt.datetime.fromisoformat(str(text).replace('Z','+00:00'))
        return value if value.tzinfo else None
    except (ValueError,TypeError): return None

def owned_file(path, private=False):
    p=Path(path)
    if p.is_symlink(): raise ValueError('Symlink not permitted for approved configuration')
    s=p.stat()
    if not stat.S_ISREG(s.st_mode) or s.st_uid!=0 or s.st_mode & 0o022:
        raise ValueError('Approved configuration must be a root-owned regular file, not writable by group/others')
    if private and s.st_mode & 0o077: raise ValueError('Secret configuration requires mode 0600')
    return p

def env_file(path):
    result={}
    for line in owned_file(path,True).read_text().splitlines():
        if not line.strip() or line.lstrip().startswith('#'): continue
        if line.startswith('export '): line=line[7:]
        if not re.match(r'^[A-Z][A-Z0-9_]*=',line): raise ValueError('Environment file must contain literal KEY=value assignments only')
        key,value=line.split('=',1)
        if '$' in value or '`' in value: raise ValueError('Environment expansion is not supported')
        tokens=shlex.split(value,comments=True)
        if len(tokens)>1: raise ValueError('Quote environment values containing spaces')
        result[key]=tokens[0] if tokens else ''
    return result

def run(argv,env=None,timeout=90,limit=LIMIT):
    started=now(); out=bytearray(); err=bytearray(); problem=None
    try:
        proc=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env or {'PATH':'/usr/sbin:/usr/bin:/sbin:/bin','LANG':'C.UTF-8'},start_new_session=True)
    except OSError as ex:
        return {'status':'error','error':type(ex).__name__,'collected_at':started,'stdout':''}
    sel=selectors.DefaultSelector()
    sel.register(proc.stdout,selectors.EVENT_READ,out);sel.register(proc.stderr,selectors.EVENT_READ,err)
    end=time.monotonic()+timeout
    try:
        while sel.get_map():
            if time.monotonic()>end: problem='timeout';break
            for key,_ in sel.select(.2):
                data=os.read(key.fileobj.fileno(),65536)
                if not data: sel.unregister(key.fileobj);continue
                key.data.extend(data)
                if len(out)+len(err)>limit: problem='output_limit';break
            if problem:break
        if problem:
            os.killpg(proc.pid,signal.SIGKILL)
        rc=proc.wait(timeout=5)
    finally:
        sel.close();proc.stdout.close();proc.stderr.close()
    # stderr may contain repository URLs or backend credentials. Never export it.
    return {'status':'ok' if not problem and rc==0 else 'error','error':problem or (f'exit_{rc}' if rc else None),'exit_code':rc,'collected_at':started,'completed_at':now(),'stdout':out[:limit].decode(errors='replace'),'stderr_bytes':len(err)}

def read_tail(path,limit=LIMIT):
    try:
        with open(path,'rb') as f:
            size=os.fstat(f.fileno()).st_size
            if size>limit:
                f.seek(-limit,2);f.readline()
            raw=f.read(limit)
        return {'status':'ok','text':raw.decode(errors='replace'),'truncated':size>limit,'size_bytes':size}
    except OSError as ex:return {'status':'error','error':type(ex).__name__,'text':''}

def sanitize(text,secrets):
    for value in sorted(set(secrets),key=len,reverse=True):
        if len(value)>=4:text=text.replace(value,'[REDACTED]')
    # Defense in depth for literal assignments in custom scripts or unit files.
    return re.sub(r'(?im)^.*(?:AWS_(?:SECRET_ACCESS_KEY|ACCESS_KEY_ID|SESSION_TOKEN)|RESTIC_PASSWORD|PASSWORD|TOKEN|SECRET)\s*=.*$', '[REDACTED ASSIGNMENT]',text)

def collect(cfg):
    begin=now();e={'schema_version':1,'collector_version':VERSION,'collection_id':dt.datetime.now(UTC).strftime('%Y%m%dT%H%M%S')+'-'+os.urandom(6).hex(),'started_at':begin,'host':socket.gethostname(),'approved_target':{k:cfg[k] for k in ('target_id','expected_host','timer','service','script','runs_log')},'sources':{},'repositories':{},'errors':[]}
    try:
        secrets=env_file(cfg['env_file'])
        password_path=owned_file(secrets['RESTIC_PASSWORD_FILE'],True)
        secret_values=[v for k,v in secrets.items() if k.startswith('AWS_') and k not in ('AWS_DEFAULT_REGION','AWS_REGION')]
        secret_values.append(password_path.read_text().strip())
    except Exception as ex:
        e['errors'].append('Credential configuration unavailable: '+type(ex).__name__)
        secrets={};secret_values=[]
    clean=lambda t:sanitize(t,secret_values)
    actions={
        'timer_unit':['/usr/bin/systemctl','cat',cfg['timer']],
        'service_unit':['/usr/bin/systemctl','cat',cfg['service']],
        'timer_state':['/usr/bin/systemctl','show',cfg['timer'],'--property=ActiveState,UnitFileState,LastTriggerUSec,NextElapseUSecRealtime,TimersCalendar'],
        'service_state':['/usr/bin/systemctl','show',cfg['service'],'--property=ActiveState,Result,ExecMainStatus,ExecMainStartTimestamp,ExecMainExitTimestamp'],
        'clock':['/usr/bin/timedatectl','show','--property=NTPSynchronized,Timezone'],
        'journal':['/usr/bin/journalctl','-u',cfg['service'],'--since',f"{int(cfg.get('lookback_hours',24))} hours ago",'--no-pager','-o','json','-n','20000'],
        'restic_version':[cfg['restic_binary'],'version']}
    for name,args in actions.items():
        result=run(args,timeout=30)
        # Unit/script raw text can contain secrets not known to this collector.
        # Export selected directives only; never export full unit environment or journal messages.
        raw=result.pop('stdout','')
        if name in ('timer_unit','service_unit'):
            safe_prefixes=('OnCalendar=','AccuracySec=','RandomizedDelaySec=','Persistent=','Unit=','Type=')
            lines=[line.strip() for line in raw.splitlines() if line.strip().startswith(safe_prefixes)]
            if name=='service_unit':
                result['configured_script_reference_found']=cfg['script'] in raw
            result['text']='\n'.join(lines)
        elif name=='journal':
            records=[];bad=0
            for line in raw.splitlines():
                try:
                    j=json.loads(line);records.append({k:j[k] for k in ('__REALTIME_TIMESTAMP','_SYSTEMD_UNIT','_SYSTEMD_INVOCATION_ID','PRIORITY') if k in j})
                except (ValueError,TypeError):bad+=1
            result['records']=records;result['malformed_lines']=bad
        else:result['text']=clean(raw)
        e['sources'][name]=result
    # Hash script for change tracking and extract only safe, bounded indicators.
    try:
        raw=owned_file(cfg['script']).read_bytes()
        if len(raw)>LIMIT:raise ValueError('Script too large')
        text=raw.decode(errors='replace')
        e['sources']['script']={'status':'ok','sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw),'restic_reference_found':bool(re.search(r'\brestic\b',text)),'exclusion_option_detected':bool(re.search(r'--exclude(?:\b|-)',text)),'interpretation':'Static indicators only; script is never executed by collector'}
    except Exception as ex:e['sources']['script']={'status':'error','error':type(ex).__name__}
    history=read_tail(cfg['runs_log']);rows=[];bad=0
    cutoff=dt.datetime.now(UTC)-dt.timedelta(hours=int(cfg.get('lookback_hours',24)))
    for line in history.pop('text','').splitlines():
        try:
            row=json.loads(line)
            started=stamp(row.get('started_at'))
            if not started:bad+=1;continue
            if started<cutoff:continue
            safe={k:row.get(k) for k in ('run_id','host','started_at','ended_at','duration_seconds','status','last_stage','exit_code')}
            for dest in ('local','s3'):
                value=row.get(dest,{})
                safe[dest]={k:value.get(k) for k in ('status','snapshot_id','completed_at')}
            rows.append(safe)
        except (ValueError,TypeError,AttributeError):bad+=1
    history.update(records=rows,malformed_lines=bad,lookback_hours=int(cfg.get('lookback_hours',24)))
    e['sources']['runs']=history
    # Detect started-but-unfinished jobs without trusting paths from log contents.
    pending=[]
    root=Path(cfg['runs_log']).parent
    for p in sorted(root.glob('auto-*/started.json'))[-5000:]:
        try:
            if p.is_symlink() or p.parent.is_symlink() or p.with_name('result.json').exists():continue
            r=json.loads(p.read_text()[:4096]);s=stamp(r.get('started_at'))
            if s and s>=cutoff:pending.append({'run_id':str(r.get('run_id',''))[:200],'started_at':r['started_at']})
        except (OSError,ValueError):continue
    e['sources']['unfinished']={'status':'ok','records':pending,'limit':5000}
    for name,key in [('local','LOCAL_REPOSITORY'),('s3','S3_REPOSITORY')]:
        repo=secrets.get(key,'')
        # This pilot permits only local absolute directories and the existing AWS HTTPS endpoint form.
        valid=(name=='local' and repo.startswith('/') and '\n' not in repo) or (name=='s3' and re.fullmatch(r's3:https://s3\.[a-z0-9-]+\.amazonaws\.com/[a-z0-9.-]+/[A-Za-z0-9/_.-]+',repo))
        if not valid:
            e['repositories'][name]={'status':'error','error':'Missing or unsupported repository URI; use a literal URI without Markdown formatting'};continue
        renv={'PATH':'/usr/bin:/bin','HOME':'/root','LANG':'C.UTF-8','AWS_EC2_METADATA_DISABLED':'true'}
        for k in ('AWS_ACCESS_KEY_ID','AWS_SECRET_ACCESS_KEY','AWS_SESSION_TOKEN','AWS_DEFAULT_REGION','AWS_REGION','RESTIC_PASSWORD_FILE'):
            if k in secrets:renv[k]=secrets[k]
        args=[cfg['restic_binary'],'--no-lock','--no-cache','-r',repo,'snapshots','--json','--host',cfg['expected_host'],'--tag',cfg.get('tag','niraapadh-rpo')]
        result=run(args,renv,timeout=120);raw=result.pop('stdout','');result['repository']=repo;result['observed_at']=result.get('completed_at',now())
        if result['status']=='ok':
            try:
                snapshots=json.loads(raw)
                if not isinstance(snapshots,list):raise ValueError()
                result['snapshots']=[{k:s.get(k) for k in ('id','time','hostname','paths','excludes','tags','summary','program_version')} for s in snapshots]
            except (ValueError,TypeError,AttributeError):result.update(status='error',error='Invalid Restic JSON')
        e['repositories'][name]=result
    e['completed_at']=now()
    def scrub(value):
        if isinstance(value,str):return clean(value)
        if isinstance(value,list):return [scrub(x) for x in value]
        if isinstance(value,dict):return {k:scrub(v) for k,v in value.items()}
        return value
    return scrub(e)

def main():
    if os.geteuid()!=0:raise SystemExit('Collector must run through its root-owned systemd service')
    cfg=json.loads(owned_file(CONFIG).read_text())
    for k in ('timer','service'):
        if not re.fullmatch(r'[A-Za-z0-9_.@-]+',cfg[k]):raise ValueError('Invalid approved unit name')
    if not Path(cfg['restic_binary']).is_absolute():raise ValueError('Absolute Restic binary required')
    owned_file(cfg['restic_binary'])
    result=collect(cfg)
    spool=Path('/var/lib/niraapadh-collector');spool.mkdir(exist_ok=True)
    import grp
    group=grp.getgrnam('niraapadh-evidence').gr_gid
    fd,temp=tempfile.mkstemp(prefix='.pending-',dir=spool)
    try:
        os.fchmod(fd,0o640);os.fchown(fd,0,group)
        with os.fdopen(fd,'w') as f:json.dump(result,f,separators=(',',':'));f.flush();os.fsync(f.fileno())
        os.replace(temp,spool/(result['collection_id']+'.json'))
    finally:
        if os.path.exists(temp):os.unlink(temp)
    print(json.dumps({'collection_id':result['collection_id'],'status':'completed','repository_status':{k:v['status'] for k,v in result['repositories'].items()}}))
if __name__=='__main__':main()
