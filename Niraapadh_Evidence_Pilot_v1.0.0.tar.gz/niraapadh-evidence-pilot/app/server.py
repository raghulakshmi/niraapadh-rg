import functools,json,os,re,secrets,sqlite3,subprocess,threading,time
from pathlib import Path
from datetime import datetime,timedelta,timezone
from flask import Flask,request,jsonify,session,send_from_directory,abort
from werkzeug.security import check_password_hash
from . import store
from .adapter import ts
CONFIG=Path(os.environ.get('NIRAAPADH_WEB_CONFIG','/etc/niraapadh-evidence/web.json'))
ADAPTERS=[{'id':'restic-driveit-json','name':'Restic + DriveIT job JSON','version':'1.0.0','available':True},{'id':'windows-server-backup','name':'Windows Server Backup','available':False},{'id':'veeam','name':'Veeam','available':False}]

def validate(p,target):
    required=('name','customer','host','target_id','adapter','timer','service','script','runs_log','local_repository','bucket','region','prefix','tag','policy_ref','policy_status')
    for k in required:
        if not isinstance(p.get(k),str) or not p[k].strip() or len(p[k])>512:raise ValueError('Missing or invalid field: '+k)
        p[k]=p[k].strip()
    if p['adapter']!='restic-driveit-json':raise ValueError('Adapter is not implemented')
    if p['target_id']!=target['target_id']:raise ValueError('Select the approved local collector target')
    if p['policy_status'] not in ('draft','approved','unknown'):raise ValueError('Invalid policy status')
    for k in ('paths','exclusions'):
        if not isinstance(p.get(k),list) or len(p[k])>100 or any(not isinstance(v,str) or not v or len(v)>1024 for v in p[k]):raise ValueError('Invalid '+k)
    if not p['paths'] or any(not v.startswith('/') for v in p['paths']):raise ValueError('At least one absolute protected path is required')
    for k,low,high in [('rpo_minutes',1,10080),('schedule_minutes',1,1440),('lookback_hours',1,168),('completion_grace_seconds',0,3600)]:
        if isinstance(p.get(k),bool) or not isinstance(p.get(k),int) or not low<=p[k]<=high:raise ValueError('Invalid '+k)
    if not re.fullmatch(r'[a-z0-9.-]{3,63}',p['bucket']):raise ValueError('Invalid S3 bucket')
    if not re.fullmatch(r'[a-z0-9-]+',p['region']):raise ValueError('Invalid AWS region')
    if not re.fullmatch(r'[A-Za-z0-9/_.-]+',p['prefix']):raise ValueError('Invalid repository prefix')
    if not p['local_repository'].startswith('/'):raise ValueError('Local repository must be absolute')
    # Only validated fields are persisted. No commands or credentials accepted.
    return {k:p[k] for k in (*required,'paths','exclusions','rpo_minutes','schedule_minutes','lookback_hours','completion_grace_seconds')}

def create_app(config=None):
    cfg=config or json.loads(CONFIG.read_text())
    app=Flask(__name__,static_folder='static')
    app.config.update(SECRET_KEY=cfg['session_secret'],MAX_CONTENT_LENGTH=32768,SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Strict',SESSION_COOKIE_SECURE=cfg.get('https',False),PERMANENT_SESSION_LIFETIME=timedelta(hours=8))
    store.init();failures=[];gate=threading.Lock();job={'running':False,'message':'Not requested','started_at':None}
    origins=set(cfg.get('allowed_origins',['http://localhost:8787','http://127.0.0.1:8787']))
    hosts={o.split('://',1)[1] for o in origins}
    @app.before_request
    def guards():
        if request.host not in hosts:abort(400,description='Unapproved host')
        if request.method in ('POST','PUT','DELETE'):
            if request.headers.get('Origin') not in origins:abort(403,description='Unapproved origin')
            if request.path!='/api/login' and not secrets.compare_digest(request.headers.get('X-CSRF-Token',''),session.get('csrf','!')):abort(403,description='Invalid CSRF token')
    @app.after_request
    def headers(response):
        response.headers['Content-Security-Policy']="default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        response.headers['X-Content-Type-Options']='nosniff';response.headers['Referrer-Policy']='no-referrer';response.headers['Cache-Control']='no-store'
        return response
    def auth(fn):
        @functools.wraps(fn)
        def wrapped(*a,**kw):
            if not session.get('user'):return jsonify(error='Sign in required'),401
            return fn(*a,**kw)
        return wrapped
    @app.errorhandler(400)
    @app.errorhandler(403)
    @app.errorhandler(404)
    @app.errorhandler(413)
    def error(ex):return jsonify(error=ex.description),ex.code
    @app.get('/')
    def index():return send_from_directory(app.static_folder,'index.html')
    @app.post('/api/login')
    def login():
        with gate:
            failures[:]=[t for t in failures if t>time.time()-300]
            if len(failures)>=10:return jsonify(error='Too many failed attempts; wait five minutes'),429
        data=request.get_json(silent=True) or {}
        if data.get('username')!=cfg['username'] or not check_password_hash(cfg['password_hash'],str(data.get('password',''))):
            with gate:failures.append(time.time())
            return jsonify(error='Invalid credentials'),401
        session.clear();session['user']=cfg['username'];session['csrf']=secrets.token_urlsafe(32);session.permanent=True
        store.audit(cfg['username'],'login','');return jsonify(csrf=session['csrf'])
    @app.post('/api/logout')
    @auth
    def logout():session.clear();return jsonify(ok=True)
    @app.get('/api/bootstrap')
    @auth
    def bootstrap():return jsonify(csrf=session['csrf'],adapters=ADAPTERS,target=cfg['target'],profiles=store.list_profiles(),collector_interval_minutes=5)
    @app.post('/api/profiles')
    @auth
    def save():
        data=request.get_json(silent=True) or {};ident=data.pop('id',None)
        if ident and ident not in {p['id'] for p in store.list_profiles()}:abort(404)
        try:p=validate(data,cfg['target']);ident=store.save_profile(p,ident)
        except (ValueError,sqlite3.IntegrityError) as ex:return jsonify(error=str(ex) if isinstance(ex,ValueError) else 'Profile name already exists'),400
        store.audit(session['user'],'save_profile',ident)
        return jsonify(id=ident)
    @app.get('/api/profiles/<ident>/results')
    @auth
    def results(ident):
        with store.db() as c:
            p=c.execute('SELECT revision FROM profiles WHERE id=?',(ident,)).fetchone()
            if not p:abort(404)
            rows=c.execute('SELECT a.body,c.sha256,c.collected_at FROM assessments a JOIN collections c ON c.id=a.collection_id WHERE a.profile_id=? AND a.revision=? ORDER BY c.collected_at DESC LIMIT 100',(ident,p['revision'])).fetchall()
        observations=[dict(json.loads(r['body']),evidence_sha256=r['sha256']) for r in rows]
        age=(datetime.now(timezone.utc)-ts(rows[0]['collected_at'])).total_seconds() if rows and ts(rows[0]['collected_at']) else None
        return jsonify(observations=observations,collection_age_seconds=age,stale=age is None or age>600,job=job,server_time=store.now())
    @app.get('/api/evidence/<ident>')
    @auth
    def evidence(ident):
        with store.db() as c:r=c.execute('SELECT body,sha256 FROM collections WHERE id=?',(ident,)).fetchone()
        if not r:abort(404)
        store.audit(session['user'],'read_evidence',ident)
        return jsonify(sha256=r['sha256'],evidence=json.loads(r['body']))
    def run_collection():
        try:
            result=subprocess.run(['/usr/bin/sudo','-n','/usr/bin/systemctl','start','niraapadh-evidence-collector.service'],capture_output=True,timeout=480)
            # Do not send stderr or subprocess command output to the browser.
            if result.returncode:job['message']='Collector service failed; inspect its server journal'
            else:store.ingest();job['message']='Collection completed; inspect evidence-source statuses'
        except Exception:job['message']='Collection failed or timed out; inspect the collector service'
        finally:job['running']=False
    @app.post('/api/collect')
    @auth
    def collect():
        with gate:
            if job['running']:return jsonify(error='Collection is already running'),409
            if job['started_at'] and time.time()-job['started_at']<60:return jsonify(error='Wait 60 seconds between manual collections'),429
            job.update(running=True,message='Collecting actual host and repository evidence',started_at=time.time())
        store.audit(session['user'],'collect',cfg['target']['target_id']);threading.Thread(target=run_collection,daemon=True).start()
        return jsonify(job),202
    return app
