"""Restic + DriveIT structured-run adapter. No command execution."""
from datetime import datetime,timedelta,timezone
import posixpath
import re
UTC=timezone.utc
VERSION='1.0.0'

def ts(value):
    try:
        d=datetime.fromisoformat(str(value).replace('Z','+00:00'))
        return d if d.tzinfo else None
    except (ValueError,TypeError): return None

def minutes(text):
    expressions=[]
    for line in text.splitlines():
        if line.startswith('OnCalendar='):
            value=line.split('=',1)[1].strip()
            if not value:expressions=[]
            else:expressions.append(value)
    if len(expressions)!=1:return None
    m=re.fullmatch(r'\*-\*-\* \*:([0-9,]+):00 UTC',expressions[0])
    if not m:return None
    values=sorted(set(int(v) for v in m[1].split(',')))
    if not values or values[-1]>59:return None
    return values

def scope_matches(s,p):
    # Exact path sets are intentionally conservative for this pilot.
    norm=lambda xs:{posixpath.normpath(x) for x in xs if isinstance(x,str)}
    return norm(s.get('paths') or [])==norm(p['paths']) and set(s.get('excludes') or [])==set(p['exclusions'])

def assess(p,e):
    at=ts(e.get('completed_at'))
    out={'adapter':'restic-driveit-json@'+VERSION,'collection_id':e.get('collection_id'),'evaluated_at':e.get('completed_at'),'policy_reference':p['policy_ref'],'policy_status':p['policy_status'],'target_rpo_minutes':p['rpo_minutes'],'repositories':{},'findings':[], 'overall':'insufficient_evidence','rpo_assurance':'Not established: snapshot start is a proxy, not an application-consistency guarantee','restore_assurance':'Not tested','historical_rpo':'Not established; assessments are observations, not continuous coverage'}
    sources=e.get('sources',{})
    history=sources.get('runs',{})
    rows=[r for r in history.get('records',[]) if r.get('host')==p['host'] and ts(r.get('started_at'))]
    rows.sort(key=lambda r:ts(r['started_at']))
    cutoff=at-timedelta(hours=p['lookback_hours']) if at else None
    if cutoff:rows=[r for r in rows if ts(r['started_at'])>=cutoff]
    out['recent_executions']=rows[-3:][::-1]
    out['executions_in_window']=len(rows)
    approved=e.get('approved_target',{})
    out['configuration_matches']={k:p[k]==approved.get(k) for k in ('timer','service','script','runs_log')}
    out['configuration_matches']['host']=p['host']==approved.get('expected_host')==e.get('host')
    if not all(out['configuration_matches'].values()):out['findings'].append('Declared target/job differs from approved collector target')
    if not sources.get('service_unit',{}).get('configured_script_reference_found') or not sources.get('script',{}).get('restic_reference_found'):
        out['findings'].append('Service-to-script-to-Restic linkage is not fully observed')
    clock=sources.get('clock',{})
    out['clock_synchronized']=clock.get('status')=='ok' and 'NTPSynchronized=yes' in clock.get('text','')
    if not out['clock_synchronized']:out['findings'].append('Clock synchronization is unverified; freshness timestamps need review')
    for dest in ('local','s3'):
        repo=e.get('repositories',{}).get(dest,{})
        r={'status':'insufficient_evidence','observed_at':repo.get('observed_at'),'repository':repo.get('repository'),'snapshot_count':len(repo.get('snapshots',[])),'age_minutes':None,'conflicts':[]}
        out['repositories'][dest]=r
        if repo.get('status')!='ok':r['reason']=repo.get('error','No repository evidence');continue
        expected=p['local_repository'] if dest=='local' else f"s3:https://s3.{p['region']}.amazonaws.com/{p['bucket']}/{p['prefix']}"
        if repo.get('repository')!=expected:r.update(status='configuration_mismatch',reason='Declared destination differs from queried repository');continue
        raw_snapshots=repo.get('snapshots',[])
        if any(not isinstance(s,dict) or not isinstance(s.get('id'),str) or not re.fullmatch(r'[0-9a-f]{64}',s['id']) or not ts(s.get('time')) or any(not isinstance(s.get(k) or [],list) or any(not isinstance(x,str) for x in (s.get(k) or [])) for k in ('paths','excludes','tags')) for s in raw_snapshots):
            r['reason']='Malformed snapshot metadata';continue
        snaps=[s for s in raw_snapshots if s.get('hostname')==p['host'] and p['tag'] in (s.get('tags') or [])]
        valid=[s for s in snaps if scope_matches(s,p) and ts(s.get('time'))]
        ids={s.get('id') for s in snaps}
        for row in rows:
            result=row.get(dest) or {}
            if result.get('status')=='success' and result.get('snapshot_id') not in ids:
                r['conflicts'].append({'run_id':row.get('run_id'),'reason':'Success log has no matching retained snapshot; investigate retention or inconsistent evidence'})
        if not valid:
            r.update(status='scope_mismatch' if snaps else 'no_recovery_point',reason='No snapshot matches declared host, tag, exact protected paths and exclusions');continue
        latest=max(valid,key=lambda s:ts(s['time']));r['snapshot_id']=latest['id'];r['snapshot_time']=latest['time'];r['scope']='Exact path/exclusion declarations matched metadata; contents and restore not verified'
        matching=[x for x in rows if (x.get(dest) or {}).get('snapshot_id')==latest['id']]
        r['job_completed_at']=(matching[-1].get(dest) or {}).get('completed_at') if matching else None
        r['availability_basis']='Observed in repository at collection time; job completion, when present, is corroborating log evidence'
        r['timestamp_basis']='Restic snapshot start time; conservative freshness proxy only'
        age=(at-ts(latest['time'])).total_seconds()/60 if at else None
        if age is None or age<0:r.update(reason='Invalid/future timestamp');continue
        r['age_minutes']=round(age,2)
        if not out['clock_synchronized']:r['reason']='Clock synchronization unverified';continue
        r['status']='freshness_exceeded' if age>p['rpo_minutes'] else 'freshness_within_target'
    timer=sources.get('timer_unit',{});slots=minutes(timer.get('text','')) if timer.get('status')=='ok' else None
    out['timer_active']='ActiveState=active' in sources.get('timer_state',{}).get('text','')
    out['observed_calendar']=timer.get('text','')
    out['last_three_expected']=[]
    out['schedule_status']='unsupported_or_unavailable'
    if slots and at:
        gaps=[(slots[(i+1)%len(slots)]-v)%60 or 60 for i,v in enumerate(slots)]
        out['observed_max_interval_minutes']=max(gaps)
        out['schedule_status']='matches' if len(set(gaps))==1 and gaps[0]==p['schedule_minutes'] else 'mismatch'
        expected=[];cursor=at.replace(second=0,microsecond=0)
        for _ in range(181):
            if cursor.minute in slots:expected.append(cursor)
            if len(expected)==3:break
            cursor-=timedelta(minutes=1)
        for slot in expected:
            matched=[r for r in rows if 0<=(ts(r['started_at'])-slot).total_seconds()<=60]
            pending=[r for r in sources.get('unfinished',{}).get('records',[]) if ts(r.get('started_at')) and 0<=(ts(r['started_at'])-slot).total_seconds()<=60]
            status='pending' if at<slot+timedelta(seconds=p['completion_grace_seconds']) else 'missing'
            if matched:status='success' if any(r.get('status')=='success' and r.get('exit_code')==0 for r in matched) else 'failed'
            elif pending:status='running_or_interrupted'
            elif history.get('status')!='ok' or history.get('truncated') or history.get('malformed_lines'):status='insufficient_evidence'
            out['last_three_expected'].append({'expected_at':slot.isoformat(),'status':status,'run_ids':[r['run_id'] for r in matched],'attribution':'Timestamp match within 60s, not proof of timer initiation'})
    if history.get('status')!='ok' or history.get('truncated') or history.get('malformed_lines'):out['findings'].append('Run-history evidence is unavailable or incomplete')
    if p['lookback_hours']>history.get('lookback_hours',0):out['findings'].append('Requested lookback exceeds collected history')
    if not out['timer_active']:out['findings'].append('Backup timer is not observed active')
    if out['schedule_status']!='matches':out['findings'].append('Declared schedule is unverified or differs from observed calendar')
    if p['policy_status']!='approved':out['findings'].append('Policy approval has not been declared; target is provisional')
    states=[r['status'] for r in out['repositories'].values()]
    if any(s in ('freshness_exceeded','scope_mismatch','no_recovery_point','configuration_mismatch') for s in states) or not all(out['configuration_matches'].values()):out['overall']='issue_detected'
    elif all(s=='freshness_within_target' for s in states):out['overall']='freshness_observed'
    if any(r['conflicts'] for r in out['repositories'].values()):out['findings'].append('One or more success records lack matching retained snapshots')
    return out
