import hashlib,json,os,sqlite3,uuid
from pathlib import Path
from datetime import datetime,timezone
from .adapter import assess
STATE=Path(os.environ.get('NIRAAPADH_STATE','/var/lib/niraapadh-evidence'))
SPOOL=Path(os.environ.get('NIRAAPADH_SPOOL','/var/lib/niraapadh-collector'))
def now():return datetime.now(timezone.utc).isoformat()
def db():
    STATE.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(STATE/'evidence.sqlite3',timeout=30);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');return c

def init():
    with db() as c:
        c.executescript('''PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS profiles(id TEXT PRIMARY KEY,name TEXT UNIQUE NOT NULL,revision INTEGER NOT NULL,body TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS profile_versions(profile_id TEXT,revision INTEGER,body TEXT,created_at TEXT,PRIMARY KEY(profile_id,revision));
CREATE TABLE IF NOT EXISTS collections(id TEXT PRIMARY KEY,collected_at TEXT,sha256 TEXT,body TEXT);
CREATE TABLE IF NOT EXISTS assessments(profile_id TEXT,revision INTEGER,collection_id TEXT,body TEXT,PRIMARY KEY(profile_id,revision,collection_id));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,at TEXT,actor TEXT,action TEXT,object_id TEXT);
''')

def audit(actor,action,ident):
    with db() as c:c.execute('INSERT INTO audit(at,actor,action,object_id) VALUES(?,?,?,?)',(now(),actor,action,ident))

def ingest():
    init()
    with db() as c:
        for f in sorted(SPOOL.glob('*.json')):
            if f.stat().st_size>32*1024*1024:continue
            if c.execute('SELECT 1 FROM collections WHERE id=?',(f.stem,)).fetchone():continue
            raw=f.read_bytes()
            try:e=json.loads(raw)
            except ValueError:continue
            if e.get('collection_id')!=f.stem:continue
            c.execute('INSERT OR IGNORE INTO collections VALUES(?,?,?,?)',(e['collection_id'],e['completed_at'],hashlib.sha256(raw).hexdigest(),raw.decode()))
        # Fill evaluations for every saved profile version against newly imported evidence.
        for row in c.execute('SELECT * FROM profiles').fetchall():
            p=json.loads(row['body'])
            for ev in c.execute('SELECT id,body FROM collections WHERE id NOT IN (SELECT collection_id FROM assessments WHERE profile_id=? AND revision=?)',(row['id'],row['revision'])).fetchall():
                e=json.loads(ev['body'])
                if e.get('approved_target',{}).get('target_id')!=p['target_id']:continue
                c.execute('INSERT OR IGNORE INTO assessments VALUES(?,?,?,?)',(row['id'],row['revision'],ev['id'],json.dumps(assess(p,e))))

def list_profiles():
    with db() as c:return [dict(json.loads(r['body']),id=r['id'],revision=r['revision'],updated_at=r['updated_at']) for r in c.execute('SELECT * FROM profiles ORDER BY updated_at DESC')]

def save_profile(p,ident=None):
    ident=ident or str(uuid.uuid4())
    with db() as c:
        old=c.execute('SELECT revision FROM profiles WHERE id=?',(ident,)).fetchone();revision=old[0]+1 if old else 1
        body=json.dumps(p)
        c.execute('INSERT INTO profiles VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,revision=excluded.revision,body=excluded.body,updated_at=excluded.updated_at',(ident,p['name'],revision,body,now()))
        c.execute('INSERT INTO profile_versions VALUES(?,?,?,?)',(ident,revision,body,now()))
    return ident
