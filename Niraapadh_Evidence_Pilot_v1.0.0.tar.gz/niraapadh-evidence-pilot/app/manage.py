import getpass,json,os,secrets,sys
from pathlib import Path
from werkzeug.security import generate_password_hash
from . import store

def main():
    command=sys.argv[1] if len(sys.argv)>1 else ''
    if command=='ingest':store.ingest();print('Evidence imported and profiles evaluated');return
    if command=='set-password':
        p=Path('/etc/niraapadh-evidence/web.json');cfg=json.loads(p.read_text())
        password=getpass.getpass('New analyst password (at least 14 characters): ')
        if len(password)<14:raise SystemExit('Password must contain at least 14 characters')
        if password!=getpass.getpass('Confirm password: '):raise SystemExit('Passwords do not match')
        cfg['password_hash']=generate_password_hash(password);cfg['session_secret']=secrets.token_hex(32)
        p.write_text(json.dumps(cfg,indent=2)+'\n');print('Password set. Restart niraapadh-evidence-web to invalidate old sessions.');return
    raise SystemExit('Usage: python -m app.manage ingest|set-password')
if __name__=='__main__':main()
